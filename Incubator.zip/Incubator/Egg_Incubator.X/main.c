#include <stdio.h>
#include <stdint.h>
#define _XTAL_FREQ 4000000

#define RS RD7
#define EN RD6
#define D4 RD5
#define D5 RD4
#define D6 RD3
#define D7 RD2
#define ZVC RB0
#define TRI RB7

#include <xc.h>
#include "lcd.h";

// BEGIN CONFIG
#pragma config FOSC = XT // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = ON // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF // Flash Program Memory Code Protection bit (Code protection off)
//END CONFIG

//#define delay_us(x) _delay((unsigned long)((x)*(_XTAL_FREQ/4000000.0)))
void delay_ms(uint16_t milliseconds);
void delay_us(uint16_t microseconds);

void init_ADC(void);
void Read_Temp (void);
void Cal_PID(void);

unsigned int ADCvalue = 0;
unsigned int voltage;
unsigned int Temperature;
unsigned int setPoint = 37;

unsigned int PID_error = 0;
unsigned int previous_error = 0;
unsigned int PID_value = 0;
//PID constants
unsigned int kp = 400;   
unsigned int ki= 80;   
unsigned int kd = 42;
unsigned int PID_p = 0;    
unsigned int PID_i = 0;    
unsigned int PID_d = 0; 

unsigned int cnt = 0;
int tmp = 0;
unsigned int samp = 0;

int main()
{
    char str[20];
    
    /*-------------------- Init for read Temperature  ------------------------*/
    init_ADC();
    TRISA0 = 1; 
    //End.
        
    /*--------------------------- Init for LCD  ------------------------------*/
    TRISD = 0x00;
    Lcd_Init();
    //End.
    
    /*-------------------- Config PIN for Button -----------------------------*/
    TRISB4 = 1;       //B4 as INPUT
    TRISB5 = 1;       //B5 as INPUT
    //End.

    /*------------------- Config for Zero Voltage Crossing  ------------------*/
    TRISB0 = 1;         // B0 as INPUT for Interrupt
    //End.
    
    /*------------------------- Config for Triac -----------------------------*/
    TRISB7 = 0;         // RB7 as OUTPUT
    TRI = 0; 
    //End.
    
    /*--------------------------- Config Timer1 ------------------------------*/
    TMR1 = 0xFC18;                    // Clear the Timer1 register to start counting from 0                 
    TMR1CS = 0;                  // Clear the Timer1 clock select bit to choose local clock source                 
    T1CKPS0 = 0;                 // Prescaler ratio 1:1
    T1CKPS1 = 0;                 // Prescaler ratio 1:1
    TMR1ON = 1;                  // Switch ON Timer1
    //End.
    
    
    /*------------------------ Config INTERRUPT ------------------------------*/
    GIE = 1;                     // Global Interrupt Enable bit
    INTEDG = 1;                 // Interrupt edge config bit (HIGH value means interrupt occurs every rising edge)
    INTE = 1;                   // IRQ (Interrupt request pin RB0) Interrupt Enable bit
    RBIE = 1;
    TMR1IE = 1;                 // Timer1 Interrupt enable bit
    TMR1IF = 0;                 // Clear the Interrupt flag bit for timer1        
    PEIE = 1;                   // Peripherals Interrupts enable bit 
    //End.
    
    while(1)
    {
        Read_Temp();
        
        if(samp == 1)
        {
            Cal_PID();
            samp = 0;
        }
        
        Lcd_Clear();
        sprintf(str, "Set  = %d ", setPoint);
        Lcd_Set_Cursor(1,1);
        Lcd_Write_String(str);
        sprintf(str, "Real = %d ", Temperature);        
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String(str);
    }
    return 0;
}

void init_ADC (void)// adc
{
    // chon tan so clock cho bo adc
    ADCON1bits.ADCS2 = 0, ADCON0bits.ADCS1 = 0,ADCON0bits.ADCS0 = 1;
    // chon kenh adc la kenh an0
    ADCON0bits.CHS2 = 0, ADCON0bits.CHS1 = 0, ADCON0bits.CHS0 = 0;
    // chon cach luu data
    ADCON1bits.ADFM = 1;
    // cau hinh cong vao
    ADCON1bits.PCFG3 = 1,  ADCON1bits.PCFG2 = 1,  ADCON1bits.PCFG1 = 1,  ADCON1bits.PCFG0 = 0;
    // cap nguon cho khoi adc
    ADCON0bits.ADON = 1;
}

void Read_Temp (void)// doc len 7 doan
{
    unsigned int TempValue = 0;
    ADCON0bits.GO_nDONE = 1;
    while(ADCON0bits.GO_nDONE);
    TempValue = ADRESH*256 + ADRESL;
    voltage = 5000.0f / 1023 * TempValue;
    Temperature = voltage / 10;
}

void Cal_PID(void)
{
    PID_error = setPoint - Temperature;
    if(PID_error > 30)                              //integral constant will only affect errors below 30�C             
        PID_i = 0;
    PID_p = kp * PID_error;                         //Calculate the P value
    PID_i = PID_i + (ki * PID_error);               //Calculate the I value
    PID_d = kd*(PID_error - previous_error);  //Calculate the D value
    PID_value = PID_p + PID_i + PID_d;                      //Calculate total PID value
    previous_error = PID_error; //Remember to store the previous error.

    if(PID_value < 0)
        PID_value = 0;       
    if(PID_value > 9600)
        PID_value = 9600;   
}

void __interrupt() ISR(void)
{  
    if(RBIF == 1) 
    {
        if(RB4 == 1) 
            setPoint++;
        if(RB5 == 1)
            setPoint--;
        RBIF = 0;
    }
    
    if(TMR1IF == 1)
    {               // Check the flag bit 
        TMR1 = 0xFC18; 
        cnt++; 
        if(cnt == 1000)
        {
            cnt = 0;
            samp = 1;
        }
        TMR1IF = 0;                 // Clear interrupt bit for timer1
    }               
    
    if(INTF == 1)
    {  
        __delay_us(5000);
        TRI = 1;
        __delay_us(10);
        TRI = 0;
        INTF = 0; 
    }
}


#ifndef __1wire_h
 #define  __1wire_h

int OWReset(void);
void OWWriteBit(int x);
int OWReadBit(void);
void OWWriteByte(int data);
int OWReadByte(void);
int OWTouchByte(int data);
void OWBlock(unsigned char *data, int data_len);
void Convert_Temperature(void);
unsigned int Read_Temperature_DS18S20(void);
unsigned int Read_Temperature_DS18B20(void);

#endif